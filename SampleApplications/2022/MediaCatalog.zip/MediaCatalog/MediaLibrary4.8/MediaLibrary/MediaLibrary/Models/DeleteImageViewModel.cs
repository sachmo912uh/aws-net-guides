﻿namespace MediaLibrary.Models
{
    public class DeleteImageViewModel
    {
        public string KeyName { get; set; }
        public string ImageUrl { get; set; }    

        public string DeleteType { get; set; }
    }
}
