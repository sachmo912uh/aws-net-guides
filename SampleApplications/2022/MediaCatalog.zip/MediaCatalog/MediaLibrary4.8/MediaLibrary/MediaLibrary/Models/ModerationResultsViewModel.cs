﻿namespace MediaLibrary.Models
{
    public class ModerationResultsViewModel
    {
        public bool ImageAllowed { get; set; }
        public string[] ModerationFlags { get; set; }
    }
}
