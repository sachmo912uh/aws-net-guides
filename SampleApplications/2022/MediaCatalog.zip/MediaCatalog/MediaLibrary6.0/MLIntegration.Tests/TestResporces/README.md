# net6-mlintegration
Sample code to interact with AWS ML Services.
